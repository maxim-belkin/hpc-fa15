module load gcc
gcc -O2 -o cache_test cache_test.c -std=c99
